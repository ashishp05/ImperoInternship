const handleSortingOnGym = (icon, field) => {
  document.getElementById(icon).addEventListener("click", function () {
    const urlParams = new URLSearchParams(window.location.search);
    let sortOrder = urlParams.get("sortOrder") === "desc" ? "asc" : "desc";

    if (sortOrder === "asc") {
      this.classList.remove("fa-sort");
      this.classList.add("fa-sort-up");
    } else {
      this.classList.remove("fa-sort");
      this.classList.add("fa-sort-down");
    }
    window.location.href = `/gym/sort?field=${field}&sortOrder=${sortOrder}`;
  });
};
handleSortingOnGym("sortGymNameIcon", "gymName");
handleSortingOnGym("sortOwnerNameIcon", "ownerName");
handleSortingOnGym("sortLocationIcon", "gymLocation");
handleSortingOnGym("sortPricingIcon", "pricing");
handleSortingOnGym("sortCapacityIcon", "gymCapacity");
handleSortingOnGym("sortStatusIcon", "status")

