var nums = document.querySelectorAll("input[type='text']");

nums.forEach((num) => {
  var max = 1000;
  num.addEventListener("input", () => {
    if (num.value >= max) {
      num.value = 1000;
    }

    if (num.value <= -1) {
      num.value = 0;
    }
  });
});

document.getElementById("resetGymFilter").addEventListener("click", (e) => {
  e.preventDefault();
  document.getElementById("filter").value = "";

  var inputs = document.querySelectorAll("input");

  inputs.forEach(function (input) {
    input.classList.remove("input-filtered");
  });

  document.getElementById("filterForm").submit();
});

