const handleSortingOnGym = (icon, field) => {
  document.getElementById(icon).addEventListener("click", function () {
    const urlParams = new URLSearchParams(window.location.search);
    let sortOrder = urlParams.get("sortOrder") === "desc" ? "asc" : "desc";

    if (sortOrder === "asc") {
      this.classList.remove("fa-sort");
      this.classList.add("fa-sort-up");
    } else {
      this.classList.remove("fa-sort");
      this.classList.add("fa-sort-down");
    }
    window.location.href = `/home/book/sort?field=${field}&sortOrder=${sortOrder}`;
  });
};
handleSortingOnGym("sortTitleIcon", "title");
handleSortingOnGym("sortAuthorIcon", "author");
handleSortingOnGym("sortpubDateIcon", "publicationDate");
handleSortingOnGym("sortquantityIcon", "quantity");
handleSortingOnGym("sortStatusIcon", "status");

const handleSorting = (icon, field) => {
  let sortOrder = "desc";
  document.getElementById(icon).addEventListener("click", function () {
    const urlParams = new URLSearchParams(window.location.search);
    let sortOrder = urlParams.get("sortOrder") === "desc" ? "asc" : "desc";

    if (sortOrder === "asc") {
      this.classList.remove("fa-sort");
      this.classList.add("fa-sort-up");
    } else {
      this.classList.remove("fa-sort");
      this.classList.add("fa-sort-down");
    }
    window.location.href = `/home/member/sort?field=${field}&sortOrder=${sortOrder}`;
  });
};
handleSorting("sortUidIconHome", "uId");
handleSorting("sortNameIconHome", "name");
handleSorting("sortMemberTypeIconHome", "memberType");
handleSorting("sortMemberStatusIconHome", "membershipStatus");
