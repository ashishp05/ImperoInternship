const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define the gym schema
const gymSchema = new Schema({
  gymName: {
    type: String,
    required: [true, 'Gym name is required'],
    minlength: [3, 'Gym name should be at least 3 characters'],
    maxlength: [50, 'Gym name cannot exceed 50 characters'],
    trim: true
  },
  ownerName: {
    type: String,
    required: [true, 'Owner name is required'],
    minlength: [3, 'Owner name should be at least 3 characters'],
    maxlength: [50, 'Owner name cannot exceed 50 characters'],
    trim: true
  },
  userId:{
    type : mongoose.Schema.Types.ObjectId,
    ref : "Member",
    required : true
  },
  gymCapacity: {
    type: Number,
    required: [true, 'Gym capacity is required'],
    min: [1, 'Gym capacity must be at least 1'],
    max: [1000, 'Gym capacity cannot exceed 1000']
  },
  status: {
    type: String,
    required: [true, 'Gym status is required'],
    enum: ['available', 'maintenance', 'closed'], // Enum for gym status
    default: 'available'
  },
  gymLocation: {
    type: String,
    required: [true, 'Gym location is required'],
    minlength: [3, 'Gym location should be at least 3 characters'],
    maxlength: [100, 'Gym location cannot exceed 100 characters'],
    trim: true
  },
  pricing: {
    type: String, 
    required: [true, 'Pricing information is required'],
    minlength: [3, 'Pricing information should be at least 3 characters'],
    maxlength: [100, 'Pricing information cannot exceed 100 characters'],
    trim: true
  },
  availableQuantity: {
    type: String,
    required: true,
    default: 0
  } ,
  gymDescription : {
    type: String,
    required: [true, 'Owner name is required'],
   
    trim: true
  } ,
  image :{
    type : String 
  }
}, { timestamps: true }); // Automatically adds createdAt and updatedAt fields

// Create the gym model
const Gym = mongoose.model('Gym', gymSchema);

module.exports = Gym;
