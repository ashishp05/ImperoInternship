const mongoose = require('mongoose');
const Schema = mongoose.Schema;


const bookingSchema = new Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    minlength: [3, 'Name should be at least 3 characters'],
    maxlength: [100, 'Name cannot exceed 100 characters'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email address'],
    trim: true
  },
  membershipType: {
    type: String,
    required: [true, 'Membership type is required'],
    enum: ['monthly', 'annual'],
  },
  startDate: {
    type: Date,
    required: [true, 'Start date is required'],
    validate: {
      validator: function(v) {
        return v >= new Date(); // Ensure the start date is today or in the future
      },
      message: 'Start date must be today or in the future'
    }
  },
  gymId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Gym',
    required: [true, 'Gym is required'],
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Member',
    required: [true, 'User is required'],
  },
  status: {
    type: String,
    enum: ['confirmed', 'pending', 'cancelled'],
    default: 'pending'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});



module.exports = new mongoose.model('Booking', bookingSchema);
