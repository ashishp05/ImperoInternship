const LibrarySubscriptionEmail = (email, password) => {
  return `<!DOCTYPE html>
  <html>
  
  <head>
      <meta charset="UTF-8">
      <title>Course Registration Confirmation</title>
      <style>
          body {
              background-color: #ffffff;
              font-family: Arial, sans-serif;
              font-size: 16px;
              line-height: 1.4;
              color: #333333;
              margin: 0;
              padding: 0;
          }
  
  
          .container {
              max-width: 600px;
              margin: 0 auto;
              padding: 20px;
              text-align: center;
          }
  
          .logo {
              max-width: 200px;
              margin-bottom: 20px;
          }
  
          .message {
              font-size: 18px;
              font-weight: bold;
              margin-bottom: 20px;
          }
  
          .body {
              font-size: 16px;
              margin-bottom: 20px;
          }
  
          .cta {
              display: inline-block;
              padding: 10px 20px;
              background-color: #FFD60A;
              color: #000000;
              text-decoration: none;
              border-radius: 5px;
              font-size: 16px;
              font-weight: bold;
              margin-top: 20px;
          }
  
          .support {
              font-size: 14px;
              color: #999999;
              margin-top: 20px;
          }
  
          .highlight {
              font-weight: bold;
          }
      </style>
  
  </head>
  
  <body>
      <div class="container">
          <a href="#"><h1>E-Library</h1></a>
          <div class="message">Library Subscription SuccessFully.</div>
          <div class="body">
              <p>Dear Member,</p>
              <p>You have successfully get subscription of E-Library <span class="highlight">"E-Library"</span>. We
                  are excited to have you as a participant!</p>
              <p>Please log in to your learning dashboard to access the Gyms materials and start your learning journey.
              </p>
              <p>Your Login credentials are Follows:</p>
              <span> username : ${email }</span>
              <span> password : ${password }</span>

          </div>
          <div class="support">If you have any questions or need assistance, please feel free to reach out to us at <a
                  href="mailto:ashishpatel2218@gmail.com">ashishpatel2218@gmail.com</a>. We are here to help!</div>
      </div>
  </body>
  
  </html>`;
};

module.exports = LibrarySubscriptionEmail