const { default: mongoose } = require("mongoose");
// import models
const Gym = require("../models/gymModel");
const Record = require("../models/bookingModel");

const { validationResult } = require("express-validator");
exports.getAddGym = async (req, res) => {
  try {
    return res.render("gym/add-gym", {
      title: "Add Gym Page",
      error: null,
      edit: false,
      oldInput: {},
      user: req.user,
    });
  } catch (err) {
    console.log(err);
    return res.render("gym/add-gym", {
      title: "Add Gym Page",
      error: "Something Went wrong...",
      edit: false,
      oldInput: {},
      user: req.user,
    });
  }
};

exports.getSpecificGymDetails = async (req, res) => {
  try {
    let Gym_On_Page = 6;
    const user = req.user ? req.user : null;

    let totalGyms;
    const gyms = await Gym.find({userId : req.user._id}).countDocuments();
    totalGyms = gyms;
     console.log(req.user._id)
    const page = +req.query.page || 1;
    const totalItems = +req.query.totalItems || Gym_On_Page;
    console.log(totalItems);
    const gym = await Gym.find({userId : req.user._id})
      .skip((page - 1) * totalItems)
      .limit(totalItems)
      .sort({ createdAt: -1 });

    return res.render("gym/gym-details", {
      title: "Gym Details Page",
      gym: gym,
      error: null,
      oldInput: req.query,
      currentPage: page,
      lastPage: Math.ceil(totalGyms / totalItems),
      totalItems: totalItems,
      filter: false,
      sort: false,
      user: req.user,
    });
  } catch (err) {
    console.log(err);
    return res.render("gym/gym-details", {
      title: "Gym Details Page",
      error: "Something Went wrong...",
      gym: await Gym.find().limit(4),
      oldInput: {},
      currentPage: 1,
      lastPage: 1,
      filter: false,
      sort: false,
      totalItems: req.query.totalItems,
      user: req.user,
    });
  }
}; 

exports.getGymDetails = async (req, res) => {
  try {
    let Gym_On_Page = 6;
    const user = req.user ? req.user : null;

    let totalGyms;
    const gyms = await Gym.find().countDocuments();
    totalGyms = gyms;

    const page = +req.query.page || 1;
    const totalItems = +req.query.totalItems || Gym_On_Page;
    console.log(totalItems);
    const gym = await Gym.find()
      .skip((page - 1) * totalItems)
      .limit(totalItems)
      .sort({ createdAt: -1 });

    return res.render("gym/gym-details", {
      title: "Gym Details Page",
      gym: gym,
      error: null,
      oldInput: req.query,
      currentPage: page,
      lastPage: Math.ceil(totalGyms / totalItems),
      totalItems: totalItems,
      filter: false,
      sort: false,
      user: req.user,
    });
  } catch (err) {
    console.log(err);
    return res.render("gym/gym-details", {
      title: "Gym Details Page",
      error: "Something Went wrong...",
      gym: await Gym.find().limit(4),
      oldInput: {},
      currentPage: 1,
      lastPage: 1,
      filter: false,
      sort: false,
      totalItems: req.query.totalItems,
      user: req.user,
    });
  }
};
exports.getGiveGymDetails = async (req, res) => {
  try {
  

    const id = req.params.id
    const gym = await Gym.findById(id)
      

    return res.render("gym/givegym-details", {
      title: "Gym Details Page",
      gym: gym,
      error: null,
      user: req.user,
    });
  } catch (err) {
    console.log(err);
    return res.render("gym/gym-details", {
      title: "Gym Details Page",
      error: "Something Went wrong...",
      gym: null,
      user: req.user,
    });
  }
};

exports.postAddGym = async (req, res) => {
  try {
    // Destructure the fields from the request body
    const { gymName, ownerName,gymDescription, gymCapacity, status, gymLocation, pricing } =
      req.body;
   
    // Run validation checks
    const errors = validationResult(req);

    console.log(errors);
    if (!errors.isEmpty()) {
      return res.render("gym/add-gym", {
        title: "Add Gym Page",
        error: errors.array()[0].msg,
        edit: false,
        oldInput: req.body,
        user: req.user,
      });
    }

    // Validate that all required fields are provided
    if (
      !gymName ||
      !gymCapacity ||
      !status ||
      !gymLocation ||
      !pricing ||
      !gymDescription
    ) {
      return res.render("gym/add-gym", {
        title: "Add Gym Page",
        error: "All fields are required.",
        edit: false,
        oldInput: req.body,
        user: req.user,
      });
    }
    const image = req.file;
    if (!image) {
      return res.render("auth/my-profile", {
        title: "my profile",
        error: "Image is not updated",
        user: req.user,
      });
    } 
    if( req.user.memberType != 'owner')
    {
      return res.render("gym/add-gym", {
        title: "Add Gym Page",
        error: "Only Gym Owner can add gym.",
        edit: false,
        oldInput: req.body,
        user: req.user,
      });
    }

    const imageUrl = `/images/${req.file.filename}`;

    // Check if a gym with the same name, owner, and category already exists
    const existingGym = await Gym.findOne({
      gymName: { $regex: new RegExp(`^${gymName}$`, "i") },
      ownerName: { $regex: new RegExp(`^${ownerName}$`, "i") },

      gymLocation: { $regex: new RegExp(`^${gymLocation}$`, "i") },
    });

    if (existingGym) {
      return res.render("gym/add-gym", {
        title: "Add Gym Page",
        error: "This Gym already exists in the Library.",
        edit: false,
        oldInput: req.body,
        user: req.user,
      });
    }

    // Create the new gym instance
    const gym = new Gym({
      gymName: gymName,
      ownerName:  req.user.name,
   gymDescription : gymDescription,
   userId : req.user._id,
      gymCapacity: gymCapacity,
      status: status,
      gymLocation: gymLocation,
      pricing: pricing,
      availableQuantity: gymCapacity,
      image : imageUrl   // Assuming 'availableQuantity' matches gym capacity for now
    });

    // Validate the gym data
    const error = gym.validateSync();

    if (error) {
      const errorMessages = [];

      // Collect validation error messages
      for (const field in error.errors) {
        errorMessages.push(error.errors[field].message);
      }

      return res.render("gym/add-gym", {
        title: "Add Gym Page",
        error: errorMessages.join(", "), // Display error messages
        edit: false,
        oldInput: req.body,
        user: req.user,
      });
    }

    // Update the category with the new gym

    // Save the gym
    await gym.save();

    // Redirect to the gym details page after adding the gym
    res.redirect("/gym/gym-details");
  } catch (err) {
    console.log(err);
    return res.render("gym/add-gym", {
      title: "Add Gym Page",
      error: "Something went wrong. Please try again later.",
      edit: false,
      oldInput: {},
      user: req.user,
    });
  }
};



// Edit Gym Page.....
exports.getEditGym = async (req, res) => {
  try {
    const edit = req.query.edit;
    const id = req.params.id;
    const gym = await Gym.findOne({ _id: id });
    console.log("id", id, gym);

    if (!gym) {
      return res.render("gym/add-gym", {
        title: "Edit Gym Page",
        error: "Gym not found for edit.",
        gym: {},
        edit: true,
        user: req.user,
      });
    }

    const oldInput = {
      gymName: gym.gymName,
      ownerName: gym.ownerName,
      gymCapacity: gym.gymCapacity,
      gymLocation: gym.gymLocation,
      pricing: gym.pricing,
      status: gym.status,
      user: req.user,
    };

    return res.render("gym/add-gym", {
      title: "Edit Gym Page",
      error: null,
      gym: gym,
      edit: edit,
      oldInput: oldInput,
      user: req.user,
    });
  } catch (err) {
    console.log(err);
    return res.render("gym/add-gym", {
      title: "Edit Gym Page",
      error: "Something went wrong...",
      gym: await Gym.find(),
      edit: true,
      oldInput: {},
      user: req.user,
    });
  }
};

// Edit Gym in Database.....
exports.postEditGym = async (req, res) => {
  try {
    const { gymName, ownerName, gymCapacity, gymLocation, pricing, status } =
      req.body;

    const id = req.body.id; // Gym ID to identify the gym being edited
    console.log(id);
    // Perform validation checks on the input
    const errors = validationResult(req);
    let Gym_On_Page = 6;
    const totalItems = +req.query.totalItems || Gym_On_Page;
    let totalGyms = await Gym.find().countDocuments();
    const page = +req.query.page;

    // If there are validation errors, render the form with error message
    if (!errors.isEmpty()) {
      return res.render("gym/add-gym", {
        title: "Edit Gym Page",
        error: errors.array()[0].msg,
        gym: await Gym.find(),
        edit: true,
        oldInput: req.body,
        user: req.user,
      });
    }

    // Fetch the gym by its ID
    const gym = await Gym.findById(new mongoose.Types.ObjectId(id));
    const Allgym = await Gym.find()
      .skip((page - 1) * totalItems)
      .limit(totalItems);

    // If gym not found, return an error page
    if (!gym) {
      return res.render("gym/add-gym", {
        title: "Edit Gym Page",
        error: "Gym not found.",
        gym: Allgym,
        edit: true,
        oldInput: {},
        user: req.user,
      });
    }

    // Check if all fields are filled
    if (
      !gymName ||
      !ownerName ||
      !gymCapacity ||
      !gymLocation ||
      !pricing ||
      !status
    ) {
      return res.render("gym/add-gym", {
        title: "Edit Gym Page",
        error: "All fields are required.",
        gym: Allgym,
        edit: true,
        oldInput: req.body,
        user: req.user,
      });
    }

    // If no changes in gym data, no need to update
    if (
      gym.gymName === gymName &&
      gym.ownerName === ownerName &&
      gym.gymLocation === gymLocation &&
      gym.pricing === pricing &&
      gym.status === status
    ) {
      return res.redirect("/gym/gym-details"); // Redirect to gym details if no changes
    }

    // If gym capacity is less than or equal to 0, return an error
    if (gymCapacity <= 0) {
      return res.render("gym/add-gym", {
        title: "Edit Gym Page",
        error: "Gym capacity must be greater than 0.",
        gym: gym,
        edit: true,
        oldInput: req.body,
        user: req.user,
      });
    }

    // Update gym status to "maintenance" and handle status changes accordingly
    if (status === "maintenance") {
      // Update the gym to "maintenance" status
      await Gym.findByIdAndUpdate(
        id,
        {
          $set: {
            gymName: gymName,
            ownerName: ownerName,
            gymCapacity: gymCapacity,
            gymLocation: gymLocation,
            pricing: pricing,
            status: status,
            // Update the gym's category
            availableQuantity: 0,
          },
        },
        { new: true }
      );

      const updatedGym = await Gym.find()
        .skip(totalItems * (page - 1))
        .limit(totalItems);
      return res.redirect("/gym/gym-details"); // Redirect to gym details
    }

    // If gym status is not "maintenance", update gym normally
    await Gym.findByIdAndUpdate(
      id,
      {
        $set: {
          gymName: gymName,
          ownerName: ownerName,
          gymCapacity: gymCapacity,
          gymLocation: gymLocation,
          pricing: pricing,
          status: status,
        },
      },
      { new: true }
    );

    const updatedOneGym = await Gym.findById(id);

    // If the status is "available" but the available quantity is 0, show error
    if (status === "available") {
      return res.render("gym/add-gym", {
        title: "Edit Gym Page",
        error:
          "You cannot mark the status as available because all gyms are borrowed.",
        gym: updatedOneGym,
        edit: true,
        oldInput: req.body,
        user: req.user,
      });
    }

    // If everything is fine, redirect to gym details page
    res.redirect("/gym/gym-details");
  } catch (err) {
    console.log(err);
    return res.render("gym/add-gym", {
      title: "Edit Gym Page",
      error: "Something went wrong...",
      edit: true,
      oldInput: {},
      user: req.user,
      gym: await Gym.find(),
    });
  }
};

// Delete Gym in DB...
exports.deleteGym = async (req, res) => {
  try {
    const id = req.params.id;
    const page = +req.body.page || 1;
    let Gym_On_Page = 6;
    const totalItems = +req.query.totalItems || Gym_On_Page;
    const totalGyms = await Gym.find().countDocuments();
    const gym = await Gym.find()
      .skip((page - 1) * totalItems)
      .limit(totalItems);
    const currrecord = await Record.findOne({
      "gym.gymId": new mongoose.Types.ObjectId(id),
    });
    if (!currrecord) {
      await Gym.findByIdAndDelete(id);
      return res.redirect("/gym/gym-details");
    }
    const deleteGym = currrecord.gym.find(
      (b) => b.gymId.toString() == id.toString()
    );

    if (currrecord && deleteGym.status != "returned") {
      return res.render("gym/gym-details", {
        title: "Gym details Page",
        error: "This gym is available in records so cannot delete it.",
        gym: gym,
        edit: false,
        oldInput: {},
        currentPage: page,
        lastPage: Math.ceil(totalGyms / totalItems),
        filter: false,
        sort: false,
        totalItems: totalGyms,
        user: req.user,
      });
    }

    if (currrecord.gym.length > 1) {
      await Record.findOneAndUpdate(
        { "gym.gymId": new mongoose.Types.ObjectId(id) },
        {
          $pull: { gym: { gymId: id } },
        }
      );
    } else {
      await Record.findOneAndDelete({
        "gym.gymId": new mongoose.Types.ObjectId(id),
      });
    }
    await Gym.findByIdAndDelete(new mongoose.Types.ObjectId(id));
    return res.redirect("/gym/gym-details");
  } catch (err) {
    console.log(err);
    return res.render("gym/gym-details", {
      title: "Gym Details Page",
      error: "Something Went wrong...",
      gym: await Gym.find().limit(4),
      edit: false,
      currentPage: 1,
      lastPage: 1,
      filter: false,
      sort: false,
      oldInput: {},
      user: req.user,
      totalItems: 4,
    });
  }
};

exports.gymFilter = async (req, res, next) => {
  try {
    let { filter } = req.query;

    //  console.log("filter" , filter)
    filter = filter.replace(/[^\w\s]/g, "");
    const page = +req.query.page || 1;
    const query = [];

    if (filter) {
      if (isNaN(filter)) {
        query.push({ gymName: { $regex: new RegExp(`${filter}`, "i") } });
        query.push({ ownerName: { $regex: new RegExp(`${filter}`, "i") } });
        query.push({ gymLocation: { $regex: new RegExp(`${filter}`, "i") } });
        query.push({ pricing: { $regex: new RegExp(`${filter}`, "i") } });
        query.push({ status: { $regex: new RegExp(`${filter}`, "i") } });
      } else {
        filter = +filter;
        query.push({ gymCapacity: filter });
        query.push({ pricing: { $regex: new RegExp(`${filter}`, "i") } });
      }
    }

    const Gym_On_Page = 6;
    let totalGyms = await Gym.find().countDocuments();
    let totalItems = +req.query.totalItems || Gym_On_Page;
    const fGym = await Gym.find()
      .skip((page - 1).totalItems)
      .limit(totalItems);
    totalGyms = await Gym.countDocuments(
      query.length > 0 ? { $or: query } : {}
    );

    const findGym = await Gym.find(query.length > 0 ? { $or: query } : {})
      .skip((page - 1) * totalItems)
      .limit(totalItems);

    return res.render("gym/gym-details", {
      title: "Gym Details Page",
      gym: findGym,
      error: null,
      oldInput: req.query,
      currentPage: page,
      lastPage: Math.ceil(totalGyms / totalItems),
      filter: true,
      sort: false,
      totalItems: totalItems,
      oldInput: req.query,
      user: req.user,
    });
  } catch (error) {
    console.error(error);
    return res.render("gym/gym-details", {
      title: "Gym Details Page",
      error: "Something Went wrong...",
      gym: await Gym.find().limit(4),
      edit: false,
      currentPage: 1,
      lastPage: 1,
      filter: false,
      sort: false,
      totalItems: 4,
      oldInput: req.query,
      user: req.user,
    });
  }
};

exports.sortGym = async (req, res) => {
  try {
    const field = req.query.field;
    const sortOrder = req.query.sortOrder;
    // console.log("sortOrder", sortOrder, "field", field);
    const Gym_On_Page = 6;
    const page = +req.query.page || 1;
    const totalItems = +req.query.totalItems || Gym_On_Page;
    let totalGyms = await Gym.countDocuments();

    const sort = {};
    sort[field] = sortOrder === "desc" ? -1 : 1;

    const gym = await Gym.find()
      .sort(sort)
      .skip((page - 1) * totalItems)
      .limit(totalItems);

    return res.render("gym/gym-details", {
      title: "Gym Details",
      gym: gym,
      error: null,
      oldInput: req.query,
      currentPage: page,
      lastPage: Math.ceil(totalGyms / totalItems),
      filter: false,
      sort: true,
      totalItems: totalItems,
      user: req.user,
    });
  } catch (error) {
    console.log(error);
    return res.render("gym/gym-details", {
      title: "Gym Details Page",
      error: "Something Went wrong...",
      gym: await Gym.find().limit(4),
      edit: false,
      currentPage: 1,
      lastPage: 1,
      filter: false,
      sort: false,
      totalItems: 4,
      oldInput: req.query,
      user: req.user,
    });
  }
};
