
const Member = require("../models/memberModel");
const Gym = require("../models/gymModel");
const Booking = require("../models/bookingModel");
const { default: mongoose } = require("mongoose");
exports.getDashboard = async ( req ,res) =>
{
  try { 
    
    const active = await Member.find({membershipStatus : "active"}).countDocuments()
    const inactive = await Member.find({membershipStatus : "inactive"}).countDocuments()
     const totalBookings = await Booking.find().countDocuments();
        const page = +req.query.page || 1;
        const bookingsPerPage = 3;
        const totalItems = +req.query.totalItems || bookingsPerPage;
    
       
        const bookings = await Booking.find()
          .populate("gymId")
          .skip((page - 1) * totalItems)
          .limit(totalItems)
          .sort({ createdAt: -1 });
   
  const record = await Booking.find({userId : new mongoose.Types.ObjectId(req.user._id) , }).populate("gymId")

const activeBookings = await Booking.find({userId : new mongoose.Types.ObjectId(req.user._id), status : "active" }).countDocuments()
const inactiveBookings = await Booking.find({userId : new mongoose.Types.ObjectId(req.user._id),  status: { $in: ["pending", "cancle"] } }).countDocuments() 
     if(record.length <=0)
     {
     return  res.render("auth/dashboard" , {
        title : "Dashboard" ,
        error : "",
        member : await Member.find(),
        gym : await Gym.find(),
        bookings : record,
        borrowedCount : activeBookings,
       
        returnedCount:inactiveBookings,
        active:active,
        inactive:inactive,
        user : req.user
      })
     } 
      const gymArray = record[0].gym

      
     

  
    res.render("auth/dashboard" , {
      title : "Dashboard" ,
      error : null,
      member : await Member.find(),
      gym : await Gym.find(),
      bookings : record,
      borrowedCount : activeBookings,
      returnedCount:inactiveBookings,
      active:active,
      inactive:inactive,
      user : req.user
    })
  } catch (error) {
    console.log(error)
    
  }
}

exports.getAboutPage = async ( req ,res) =>
{
   try {
    return res.render("general/about", {
      title : "About Page",
      user : req.user
    })
   } catch (error) {
    console.log(error)
    
   }
}

// In your server.js or routes file (e.g., contact.js)

exports.getContactPage = async ( req ,res) =>
{
  try { 
    const contactDetails = [
      {
        icon: "fas fa-comments",
        heading: "Chat on us",
        description: "Our friendly team is here to help.",
        details: "info@gymfinder.com"
      },
      {
        icon: "fas fa-map-marker-alt",
        heading: "Visit us",
        description: "Come and say hello at our office HQ.",
        details: "Akshya Nagar 1st Block 1st Cross, Rammurthy nagar, Ahmedabad-380016"
      },
      {
        icon: "fas fa-phone-alt",
        heading: "Call us",
        description: "Mon - Fri From 8am to 5pm",
        details: "+79848 XXXXX"
      }
    ];
   return  res.render('general/contact', { title: "contacu us", contactDetails , user : req.user  });
    
  } catch (error) {
    console.log(error

    )
    
  }
}

exports.getHomePage = async ( req ,res) =>
  {
     try {
      console.log(req.user)
      return res.render("general/home", {
        title : "Home Page",
        user : req.user
       
      })
     } catch (error) {
      console.log(error)
      
     }
  }