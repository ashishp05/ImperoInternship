// import models
const Member = require("../models/memberModel");
const Record = require("../models/bookingModel");

const { default: mongoose } = require("mongoose");
const { validationResult } = require("express-validator");
const mailTemplate = require("../utils/mailTemplates/LibrarySubscriptionEmail");
const mailsender = require("../utils/mailSender");
const Profile = require("../models/profileModel");
const bcrypt = require("bcrypt")
// Add member Page
exports.getAddMember = async (req, res) => {
  try {
    return res.render("member/add-member", {
      title: "Add Member Page",
      error: null,
      edit: false,
      oldInput: {},
      user: req.user,
    });
  } catch (err) {
    console.log(err);
    return res.render("member/add-member", {
      title: "Add Member Page",
      error: "Something Went wrong...",
      edit: false,
      oldInput: {},
      user: req.user,
    });
  }
};

// fatch all members
exports.getMemberDetails = async (req, res) => {
  try {
    const totalMember = await Member.countDocuments();
    const Member_On_Page = 6;
    const page = +req.query.page || 1;
    const totalItems = +req.query.totalItems || Member_On_Page;
    const member = await Member.find({memberType  : {$in : ["member" , "guest"]}})
      .skip((page - 1) * totalItems)
      .limit(totalItems)
      .sort({ createdAt: -1 });
    return res.render("member/member-details", {
      title: "Member Details Page",
      member: member,
      error: null,
      oldInput: req.query,
      currentPage: page,
      lastPage: Math.ceil(totalMember / totalItems),
      sort: false,
      filter: false,
      totalItems: totalItems,
      user: req.user,
    });
  } catch (err) {
    console.log(err);
    return res.render("member/member-details", {
      title: "Member Details Page",
      error: "Something Went wrong...",
      member: await Member.find().limit(4).sort({ createdAt: -1 }),
      edit: false,
      currentPage: 1,
      lastPage: 1,
      sort: false,
      filter: false,
      totalItems: 4,
      oldInput: {},
      user: req.user,
    });
  }
};

exports.getAdminMemberDetails = async (req, res) => {
  try {
    const totalMember = await Member.countDocuments({memberType : {$in : ["admin" , "owner"]}});
    const Member_On_Page = 6;
    const page = +req.query.page || 1;
    const totalItems = +req.query.totalItems || Member_On_Page;
    const member = await Member.find({memberType : {$in : ["admin" , "owner"]}})
      .skip((page - 1) * totalItems)
      .limit(totalItems)
      .sort({ createdAt: -1 });
    return res.render("member/member-details", {
      title: "Member Details Page",
      member: member,
      error: null,
      oldInput: req.query,
      currentPage: page,
      lastPage: Math.ceil(totalMember / totalItems),
      sort: false,
      filter: false,
      totalItems: totalItems,
      user: req.user,
    });
  } catch (err) {
    console.log(err);
    return res.render("member/member-details", {
      title: "Member Details Page",
      error: "Something Went wrong...",
      member: await Member.find().limit(4).sort({ createdAt: -1 }),
      edit: false,
      currentPage: 1,
      lastPage: 1,
      sort: false,
      filter: false,
      totalItems: 4,
      oldInput: {},
      user: req.user,
    });
  }
};

// Add member in Database
exports.addMemeber = async (req, res) => {
  try {
    const { name, email, memberType, membershipStatus } = req.body;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.render("member/add-member", {
        title: "Add Member Page",
        error: errors.array()[0].msg,
        edit: false,
        oldInput: req.body,
        user: req.user,
      });
    }

    if (!name || !email || !memberType || !membershipStatus) {
      return res.render("member/add-member", {
        title: "Add Member Page",
        error: "All fields are required.",
        edit: false,
        oldInput: req.body,
        user: req.user,
      });
    }
    const existingMember = await Member.findOne({ email: email });
    if (existingMember) {
      return res.render("member/add-member", {
        title: "Add Member Page",
        error: "Member is already Exist.",
        edit: false,
        oldInput: req.body,
        user: req.user,
      });
    }

    const preName = memberType.slice(0, 1).toUpperCase();
    let count = 1;
    const lastMember = await Member.findOne({
      uId: new RegExp(`^${preName}`),
    }).sort({ uId: -1 });
    if (lastMember) {
      const match = lastMember.uId.match(/\d+$/);
      if (match) {
        count = parseInt(match[0]) + 1;
      }
    }
    const uid = `${preName}${count}`;

   
  
   
   
   async function generateRandomString() {
      const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*₹';
      let result = '';
      const length = 8;
      
      for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        result += characters[randomIndex];
      }
      
      return result;
    }
    const password = (await generateRandomString()).toString()
    console.log(password)
    const hashpassword =await  bcrypt.hash(password , 12)
    const profile = await Profile.create({
      image: null,
      gender: null,
      dateOfBirth: null,
      contactNumber: null,
      collageName: null,
      department: null,
    });
   
    async function sendSubscriptionMail(email, password) {
      try {
        const responseSend = await mailsender(
          email,
          "Subscription Email",
          mailTemplate(email, password)
        );
        console.log("Email sent successfully!", responseSend);
      } catch (error) {
        console.error("Error sending email:", error); 
      }
    }


     await sendSubscriptionMail(email, password);
     const member = new Member({
      name ,
      uId: uid,
      email,
      memberType,
      membershipStatus,
      password : hashpassword ,
      profile : profile
    
    });
    const error = member.validateSync();

    if (error) {
      const errorMessages = [];

      for (const field in error.errors) {
        errorMessages.push(error.errors[field].message);
      }

      return res.render("member/add-member", {
        title: "Add Member Page",
        error: error,
        edit: false,
        oldInput: req.body,
        user: req.user,
      });
    }
     await member.save();
    res.redirect("/member/mymember-details");
  } catch (err) {
    console.log(err);
    return res.render("member/add-member", {
      title: "Add Member Page",
      error: "Something went wrong...",
      edit: false,
      oldInput: req.body,
      user: req.user,
    });
  }
};

// Edit member Page
exports.geteditMember = async (req, res) => {
  try {
    const edit = req.query.edit;
    const id = req.params.id;

    const member = await Member.findById(id);
    const memberDetails = await Member.find().sort({ createdAt: -1 });
    if (!member && !memberDetails) {
      return res.render("member/add-member", {
        title: "Edit Member Page",
        member: memberDetails,
        error: "Member is not Found..",
        edit: edit,
        oldInput: {},
        user: req.user,
      });
    }

    const oldInput = {
      name: member.name,
      email: member.email,
      memberType: member.memberType,
      membershipStatus: member.membershipStatus,
    };

    return res.render("member/add-member", {
      title: "Edit Member Page",
      error: null,
      member: member,
      edit: edit,
      oldInput: oldInput,
      user: req.user,
    });
  } catch (err) {
    console.log(err);
    return res.render("member/add-member", {
      title: "Edit-member Page",
      error: "Member is not Found..",
      edit: false,
      oldInput: {},
      user: req.user,
    });
  }
};



exports.postToggleUser = async (req, res) => {
  try {
    const { userId, statusToggleChange } = req.body;
    const data = await Member.findByIdAndUpdate(
      new mongoose.Types.ObjectId(userId),
      { $set: { membershipStatus: statusToggleChange } },
      { new: true }
    );

    res.json({ success: true, data });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};
//  Edit member in DB
exports.postEditMember = async (req, res) => {
  try {
    const { name, email, memberType, membershipStatus } = req.body;

    const page = +req.query.page || 1;
    const Member_On_Page = 6;
    const totalItems = +req.query.totalItems || Member_On_Page;
    const totalMember = await Member.find().countDocuments();
    const id = req.body.id;

    const allMembers = await Member.find()
      .skip((page - 1) * totalItems)
      .limit(totalItems).sort({ createdAt: -1 });

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.render("member/add-member", {
        title: "Edit Member Page",
        error: errors.array()[0].msg,
        member: allMembers,
        edit: true,
        oldInput: req.body,
        user: req.user,
      });
    }
    if (!name || !email || !memberType || !id) {
      return res.render("member/add-member", {
        title: "Edit Member Page",
        error: "All fields are required.",
        edit: true,
        member: allMembers,
        oldInput: req.body,
        user: req.user,
      });
    }

   
    const updatedMember = await Member.findByIdAndUpdate(
      { _id: new mongoose.Types.ObjectId(id) },
      { name, email, memberType, membershipStatus }
    );

    const existingMember = await Member.findOne({ email: email });

    if (!existingMember) {
      return res.render("member/member-details", {
        title: "Member Details Page",
        member: allMembers,
        error: "Member is already Exist.",
        edit: true,
        oldInput: req.body,
        currentPage: 1,
        lastPage: 1,
        sort: false,
        filter: false,
        totalItems: totalItems,
        user: req.user,
      });
    }
    res.redirect("/member/member-details");
  } catch (err) {
    console.log(err);
    return res.render("member/add-member", {
      title: "Edit member Page",
      member: await Member.find(),
      error: "Something went wrong...",
      edit: true,
      oldInput: req.body,
      user: req.user,
    });
  }
};

// delete member...
exports.deleteMember = async (req, res) => {
  try {
    const id = req.params.id;
    const currrecord = await Record.findOne({
      memberId: new mongoose.Types.ObjectId(id),
    });
    const page = +req.query.page || 1;
    const Member_On_Page = 6;
    const totalItems = +req.query.totalItems || Member_On_Page;
    const totalMember = await Member.find().countDocuments();
    const deleteToMember = await Member.findById(id);

    const memberDetails = await Member.find()
      .skip((page - 1) * totalItems)
      .limit(totalItems).sort({ createdAt: -1 });

    if (currrecord) {
      for (let book of currrecord.book) {
        if (book.status !== "returned") {
          return res.render("member/member-details", {
            title: "Member Details Page",
            error: " Some books are not returned by member.",
            member: memberDetails,
            edit: false,
            oldInput: req.query,
            currentPage: page,
            lastPage: Math.ceil(totalMember / totalItems),
            sort: false,
            filter: false,
            totalItems: totalItems,
            user: req.user,
          });
        }
      }
    }

    if (deleteToMember.membershipStatus == "active") {
      return res.render("member/member-details", {
        title: "Member Details Page",
        error: "Active members cannot deleted.",
        member: memberDetails,
        edit: false,
        oldInput: req.query,
        currentPage: page,
        lastPage: Math.ceil(totalMember / totalItems),
        sort: false,
        filter: false,
        totalItems: totalItems,
        user: req.user,
      });
    }
    await Member.findByIdAndDelete(id);
    const deleteRecord = await Record.findOneAndDelete({
      memberId: new mongoose.Types.ObjectId(id),
    });
    res.redirect("/member/member-details");
  } catch (err) {
    console.log(err);
    return res.render("member/member-details", {
      title: "Member Details Page",
      error: "Something Went wrong...",
      member: await Member.find().limit(6),
      edit: false,
      currentPage: 1,
      lastPage: 1,
      sort: false,
      filter: false,
      oldInput: {},
      totalItems: 6,
      user: req.user,
    });
  }
};

exports.filterMember = async (req, res) => {
  try {
    let { filter } = req.query;
    filter = filter.replace(/[^\w\s]/g, "");

    let filterArr = [];
    if (filter) {
      filterArr.push({ uId: { $regex: new RegExp(`${filter}`, "i") } });
      filterArr.push({ name: { $regex: new RegExp(`${filter}`, "i") } });
      filterArr.push({ email: { $regex: new RegExp(`${filter}`, "i") } });
      filterArr.push({ memberType: { $regex: new RegExp(`${filter}`, "i") } });
      filterArr.push({
        membershipStatus: { $regex: new RegExp(`^${filter}$`, "i") },
      });
    }

    const totalMember = await Member.find(
      filterArr.length > 0 ? { $or: filterArr } : {}
    ).countDocuments();

    const page = +req.query.page || 1;
    const Member_On_Page = 6;
    const totalItems = +req.query.totalItems || Member_On_Page;
    const findedMember = await Member.find(
      filterArr.length > 0 ? { $or: filterArr } : {}
    )
      .skip((page - 1) * totalItems)
      .limit(totalItems).sort({ createdAt: -1 });

    res.render("member/member-details", {
      title: "Member Details Page",
      member: findedMember,
      error: null,
      oldInput: req.query,
      currentPage: page,
      lastPage: Math.ceil(totalMember / totalItems),
      sort: false,
      filter: true,
      totalItems: totalItems,
      user: req.user,
    });
  } catch (error) {
    console.log(error);
    return res.render("member/member-details", {
      title: "member Details Page",
      member: await Member.find().limit(4),
      error: error,
      oldInput: {},
      currentPage: 1,
      lastPage: 1,
      sort: false,
      filter: true,
      totalItems: 4,
      user: req.user,
    });
  }
};

exports.sortMember = async (req, res) => {
  try {
    const field = req.query.field;
    const sortOrder = req.query.sortOrder;
    // console.log("sortOrder" , sortOrder ,"field", field)

    const sort = {};
    sort[field] = sortOrder === "desc" ? -1 : 1;

    const totalMember = await Member.countDocuments();
    const page = +req.query.page || 1;
    const Member_On_Page = 6;
    const totalItems = +req.query.totalItems || Member_On_Page;
    const member = await Member.find()
      .sort(sort)
      .skip((page - 1) * totalItems)
      .limit(totalItems);
    return res.render("member/member-details", {
      title: "Member Details",
      member: member,
      error: null,
      oldInput: req.query,
      currentPage: page,
      lastPage: Math.ceil(totalMember / totalItems),
      sort: true,
      filter: false,
      totalItems: totalItems,
      user: req.user,
    });
  } catch (error) {
    console.log(error);
    console.log(error);
    return res.render("member/member-details", {
      title: "member Details Page",
      member: await Member.find().limit(6).sort({ createdAt: -1 }),
      error: error,
      oldInput: {},
      currentPage: 1,
      lastPage: 1,
      sort: false,
      filter: true,
      totalItems: 6,
      user: req.user,
    });
  }
};
