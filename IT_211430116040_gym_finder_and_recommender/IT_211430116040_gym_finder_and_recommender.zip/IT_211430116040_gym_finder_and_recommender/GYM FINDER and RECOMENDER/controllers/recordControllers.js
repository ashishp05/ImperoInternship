const Booking = require("../models/bookingModel");
const Member = require("../models/memberModel");
const Gym = require("../models/gymModel");
const { default: mongoose, Types } = require("mongoose");
const { validationResult } = require("express-validator");
exports.getBookingDetails = async (req, res) => {
  try {
    const totalBookings = await Booking.find().countDocuments();
    const page = +req.query.page || 1;
    const bookingsPerPage = 3;
    const totalItems = +req.query.totalItems || bookingsPerPage;

   
    const bookings = await Booking.find()
      .populate("gymId")
      .populate("userId")
      .skip((page - 1) * totalItems)
      .limit(totalItems)
      .sort({ createdAt: -1 });

    return res.render("record/record-details", {
      title: "Booking Details Page",
      bookings: bookings,
      error: null,
      oldInput: req.query,
      edit: false,
      currentPage: page,
      lastPage: Math.ceil(totalBookings / totalItems),
      sort: false,
      filter: false,
      totalItems: totalItems,
      user: req.user
    });
  } catch (err) {
    console.log(err);
    return res.render("record/record-details", {
      title: "Booking Details Page",
      error: "Something Went wrong...",
      bookings: await Booking.find(),
      oldInput: {},
      edit: false,
      currentPage: 1,
      lastPage: 1,
      sort: false,
      filter: false,
      totalItems: 2,
      user: req.user
    });
  }
};





exports.getEditBookingForm = async (req, res) => {
  try {
    const booking = await Booking.findOne({_id : req.params.bookingId }).populate('gymId').populate("userId");
    console.log(booking)
    if (!booking) {
      return res.status(404).send("Booking not found");
    }
    res.render('record/update-record', {
      title: 'Edit Booking',
      booking: booking,
      error : null,
      user: req.user
    });
  } catch (err) {
    console.log(err);
    return res.status(500).send("Something went wrong");
  }
};

exports.updateBookingStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const updatedBooking = await Booking.findByIdAndUpdate(
      req.params.bookingId,
      { status: status },
      { new: true }
    );
    if (!updatedBooking) {
      return res.status(404).send("Booking not found");
    }
    res.redirect(`/record/record-details`);
  } catch (err) {
    console.log(err);
    return res.status(500).send("Failed to update booking");
  }
};

exports.getBookingRecord = async ( req ,res) =>
{
  try {
    const gymId = req.params.gymId;
  const user = req.user; 
 const gym =await Gym.findById(gymId)

 if(!gym)
 {
   return res.redirect("/gym/gym-details")
 }

   
    res.render('record/booking-form', {
      title : "Booking Form",
      error : null,
      oldInput : {},
      gym: gym,
      user: user
    });
  
  } catch (error) {
    console.log(error) 
  }
}

exports.postBooking = async ( req ,res) =>
{
  try {
    const { name, email, membershipType, startDate, gymId } = req.body;
  const userId = req.user._id ;

  const bookingData = {
    name,
    email,
    membershipType,
    startDate,
    gymId,
    userId,
    status: 'pending'
  };
    const existingMember = await Booking.findOne({email : email ,  status: { $in: ["pending", "active"] }})
    if(existingMember)
    {
      return res.render("record/booking-form",{ 
        title : "Booking form",
        error : "One Booking i already in Gym.",
        oldInput :req.body,
         gym : await Gym.findById(gymId),
         user :req.user

      })
    }
  const newBooking =await  new Booking(bookingData);
   const gym = await Gym.findById(gymId)
  newBooking.save()

   await Gym.findByIdAndUpdate(gymId, { $set:  { availableQuantity: gym.availableQuantity-1 }} , {new :true});
    res.redirect("/dashboard")
  } catch (error) {
    console.log(error)
    
  }
}


exports.deleteBooking = async (req, res) => {
  try {
    const booking = await Booking.findByIdAndDelete(req.params.bookingId);
    if (!booking) {
      return res.status(404).send("Booking not found");
    }
    res.redirect('/record/record-details');
  } catch (err) {
    console.log(err);
    return res.status(500).send("Failed to delete booking");
  }
};
