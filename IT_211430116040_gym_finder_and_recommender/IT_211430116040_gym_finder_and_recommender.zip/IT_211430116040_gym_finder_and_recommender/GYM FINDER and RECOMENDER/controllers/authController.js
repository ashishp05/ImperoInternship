const Member = require("../models/memberModel");
const OTP = require("../models/otpModel");
const bcrypt = require("bcrypt");
const Profile = require("../models/profileModel");
const jwt = require("jsonwebtoken");
const crypto = require("crypto")
const mailTemplate = require("../utils/mailTemplates/resetPasswordEmail");
const mailsender = require("../utils/mailSender");
exports.getSignupPage = async (req, res) => {
  try {
    res.render("auth/signup", {
      title: "SignUp Page",
      error: null,
      oldInput: {},
      user: req.user,
    });
  } catch (error) {
    console.log(error);
    res.render("auth/signup", {
      title: "SignUp Page",
      error: "something went wrong...",
      oldInput: {},
      user: req.user,
    });
  }
};

exports.getLoginPage = async (req, res) => {
  try {
    res.render("auth/login", {
      title: "SignUp Page",
      error: null,
      oldInput: {},
      user: req.user,
    });
  } catch (error) {
    console.log(error);
    res.render("auth/login", {
      title: "SignUp Page",
      error: "something went wrong...",
      oldInput: {},
      user: req.user,
    });
  }
};
exports.sendOtp = async (req, res) => {
  try {
    const { name, email, password, confirmPassword } = req.body;
    console.log("req", req.body);
    if (!name || !email || !password || !confirmPassword) {
      return res.render("auth/signup", {
        title: "Sign up page",
        error: "All Fields are Required.",
        user: req.user,
      });
    }
    if (password !== confirmPassword) {
      return res.render("auth/signup", {
        title: "Sign up page",
        error: "Password and confirmPassword are not matched.",
        user: req.user,
      });
    }
    const isPresent = await Member.findOne({ email: email });
    if (isPresent) {
      return res.render("auth/login", {
        title: "Signup Page",
        error: "Member is already present please login",
        user: req.user,
      });
    }

    let otp = Math.floor(100000 + Math.random() * 900000);
    console.log("otp", otp);
    const result = await OTP.findOne({ otp: otp });

    while (result) {
      otp = Math.floor(Math.random() * 1000000 + 1);
    }

    await OTP.deleteMany({ email });

    const newOtp = new OTP({ email, otp });
    await newOtp.save();
    console.log("otp body", newOtp);

    res.render("auth/verify-email", {
      title: "Verify email",
      error: null,
      signupData: {
        name: name,
        email: email,
        password: password,
        confirmPassword: confirmPassword,
      },
      user: req.user,
    });
  } catch (error) {
    console.log(error);
  }
};

exports.verifyEmail = async (req, res) => {
  try {
    res.render("auth/verify-email", {
      title: "verify -email",
      error: null,
      user: req.user,
    });
  } catch (error) {
    console.log(error);
  }
};

exports.signup = async (req, res) => {
  try {
    let signupData = JSON.parse(req.body.signupData);
    const otp = req.body.otp;
    if (!signupData || !otp) {
      return res.render("auth/signup", {
        title: "signup",
        error: "invalid credentials",
        user: req.user,
      });
    }

    const existingMember = await Member.findOne({ email: signupData.email });
    if (existingMember) {
      return res.render("auth/login", {
        title: "signup",
        error: "Member is already exists please LOGIN.",
        user: req.user,
      });
    }

    const currOtp = await OTP.find({ email: signupData.email });
    console.log("currOtp", currOtp[0].otp, otp);
    if (!currOtp) {
      return res.render("auth/verify-email", {
        title: "signup",
        error: "OTP is not valid. currotp",
        signupData: signupData,
        user: req.user,
      });
    }
    if (otp != currOtp[0].otp) {
      return res.render("auth/verify-email", {
        title: "signup",
        error: "OTP is not valid.",
        signupData: signupData,
        user: req.user,
      });
    }

    const hashpassword = await bcrypt.hash(signupData.password, 12);
    const profile = await Profile.create({
      image: null,
      gender: null,
      dateOfBirth: null,
      contactNumber: null,
      collageName: null,
      department: null,
    });
    const user = await Member.create({
      name: signupData.name,
      email: signupData.email,
      password: hashpassword,
      profile: profile,
      membershipStatus: "active",
      memberType: "admin",
    });
    console.log("user signin successfully");
    return res.redirect("/auth/login");
  } catch (error) {
    console.log(error);
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.render("auth/login", {
        title: "signup",
        error: "Invalid Credentiaals",
        user: req.user,
      });
    }
    const isMember = await Member.findOne({ email });
  
    if (!isMember) {
      return res.render("auth/signup", {
        title: "signup",
        error: "Member is Not Register, Please Signup",
      });
    }
    
    if(isMember.membershipStatus == 'inactive')
    {
        return res.render("auth/login", {
            title: "login page",
            error: "Member is Inactive, Please contact Admin",
            user : req.user
          });
    }
    const matchPassword = await bcrypt.compare(password, isMember.password);

    if (!matchPassword) {
      return res.render("auth/login", {
        title: "signup",
        error: "Invalid Password, please tru again",
        user :req.user
      });
    }
    console.log(".......................................................................")
    const accessToken = await jwt.sign(
      {
        email: isMember.email,
        id: isMember._id,
        memberType: isMember.memberType,
      },
      process.env.JWT_SECRET,
      { expiresIn: "24h" }
    );
    if (!accessToken) {
      returnres.render("auth/login", {
        title: "signup",
        error: "Token is invalid",
        user :req.user
      });
    }
    req.session.accessToken = accessToken;
    req.session.save((err) => {
      console.log(err);
    });
    console.log("req.token", req.session.accessToken);

    return res.redirect("/auth/my-profile");
  } catch (error) {
    console.log(error);
  }
};

exports.logout = async (req, res) => {
  try {
    if (!req.session) {
      return res.redirect("/");
    }

    console.log("Logging out user:", req.session.id);

    req.session.destroy((err) => {
      if (err) {
        console.error("Session destruction error:", err);
      }

      res.clearCookie("connect.sid"); // Clear session cookie (if using express-session)
      return res.redirect("/home");
    });
  } catch (err) {
    console.error("Logout error:", err);
    return res.status(500).json({
      success: false,
      message: "Cannot logout, please try again.",
    });
  }
};

exports.getProfile = async (req, res) => {
  try {
    if (!req.user) {
      return res.render("home", {
        title: "Home",
        error: "Unauthenticated Member,",
        user: null,
      });
    }
    const user = await Member.findById(req.user._id).populate("profile");

    return res.render("auth/my-profile", {
      title: "My Profile Page",
      error: null,
      user: user,
    });
  } catch (error) {
    console.log(error);
  }
};

exports.geteditProfile = async (req, res) => {
  try {
    const user = await Member.findById(req.user._id).populate("profile");
    const oldInput = {
      fullName: user.name || "",
      gender: user.profile.gender || "NA",
      dateOfBirth: user.profile.dateOfBirth,
      contactNumber: user.profile.contactNumber || "",
      collageName: user.profile.collageName || "",
      department: user.profile.department || "",
    };
    return res.render("auth/edit-profile", {
      title: "Edit profile",
      edit: false,
      error: null,
      oldInput: oldInput,
      user: req.user,
    });
  } catch (error) {
    console.log(error);
  }
};

exports.editProfile = async (req, res) => {
  try {
    const {
      fullName,
      gender,
      dateOfBirth,
      contactNumber,
      collageName,
      department,
    } = req.body;
    const user = await Member.findByIdAndUpdate(req.user._id);

    const pid = user.profile;
    const profile = await Profile.findByIdAndUpdate(
      pid,
      { $set: { gender, dateOfBirth, contactNumber, collageName, department } },
      { new: true }
    );

    await Member.findByIdAndUpdate(
      req.user._id,
      { $set: { name: fullName } },
      { new: true }
    );
    res.redirect("/auth/my-profile");
  } catch (error) {
    console.log(error);
  }
};

exports.geteditProfileImage = async (req, res) => {
  try {
    const image = req.file;
    if (!image) {
      return res.render("auth/my-profile", {
        title: "my profile",
        error: "Image is not updated",
        user: req.user,
      });
    }

    const user = await Member.findByIdAndUpdate(req.user._id);
    const pid = user.profile;
    const imageUrl = `/images/${req.file.filename}`;

    const profile = await Profile.findByIdAndUpdate(
      pid,
      { $set: { image: imageUrl } },
      { new: true }
    );

    res.redirect("/auth/my-profile");
  } catch (error) {
    console.log(error);
  }
};

exports.resetPasseordPofile = async (req, res) => {
  try {
    const { password, confirmPassword } = req.body;

    if (!password || !confirmPassword) {
      return res.render("auth/my-profile", {
        title: "Reset Password Page",
        error: "All fileds are required.",
        user: req.user,
      });
    }

    if (password != confirmPassword) {
      return res.render("auth/my-profile", {
        title: "Reset Password Page",
        error: "Password and confirmPassword is not matched",
        user: req.user,
      });
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const user = await Member.findByIdAndUpdate(
      req.user._id,
      { $set: { password: hashedPassword } },
      { new: true }
    );

    return res.redirect("/auth/my-profile");
  } catch (error) {
    console.log(error);
  }
};


exports.getForgotPassword = async (req, res) => {
  try {
    return res.render("auth/forgot-password", {
      title: "Login Page",
      error: null,
      oldInput: {},
      user: req.user,
    });
  } catch (error) {
    console.log(error);
    return res.render("auth/forgot-password", {
      title: "Login Page",
      error: "Something went Wrong",
      oldInput: {},
      user: req.user,
    });
  }
};

exports.forgotPassword = async (req, res) => {
  try {
    const email = req.body.email;

    const isUserPresent = await Member.findOne({ email: email });

    if (!isUserPresent) {
      return res.render("auth/forgot-password", {
        title: "Login Page",
        error: "User is Not Regestered , please Signup.",
        user: req.user,
      });
    }

    const resetPasswordToken = crypto.randomBytes(32).toString("hex");
    console.log("resetPasswordToken", resetPasswordToken);
    async function sendResetPasswordMail(email, resetPasswordToken) {
      try {
        const responseSend = await mailsender(
          email,
          "Reset Password Email",
          mailTemplate(email, resetPasswordToken)
        );
        console.log("Email sent successfully!", responseSend);
      } catch (error) {
        console.error("Error sending email:", error);
      }
    }

    await sendResetPasswordMail(email, resetPasswordToken);
    const user = await Member.findOneAndUpdate(
      { email: email },
      { $set: { resetPasswordToken: resetPasswordToken } },
      { new: true }
    );

    return res.redirect(`/auth/login`);
  } catch (error) {
    console.log(error);
  }
};

exports.getResetPassword = async (req, res) => {
  try {
    const resetPasswordToken = req.params.token;
    console.log(resetPasswordToken, " in gry");
    return res.render("auth/reset-password", {
      title: "Login Page",
      error: null,
      user: req.user,
      resetPasswordToken: resetPasswordToken,
    });
  } catch (error) {
    console.log(error);
  }
};

exports.resetPassword = async (req, res) => {
  try {
    const { password, confirmPassword, resetPasswordToken } = req.body;

    if (!password || !confirmPassword) {
      return res.render("auth/reset-password", {
        title: "Reset Password Page",
        error: "All fileds are required.",
        user: req.user,
        resetPasswordToken: null,
      });
    }

    if (password != confirmPassword) {
      return res.render("auth/reset-password", {
        title: "Reset Password Page",
        error: "Password and confirmPassword is not matched",
        user: req.user,
        resetPasswordToken: null,
      });
    }

    console.log(resetPasswordToken);

    const user = await Member.findOne({
      resetPasswordToken: resetPasswordToken,
    });

    console.log(user);

    if (!user) {
      return res.render("auth/reset-password", {
        title: "Reset Password Page",
        error: "user is not found",
        user: req.user,
        resetPasswordToken: null,
      });
    }
    const hashedPassword = await bcrypt.hash(password, 12);

    const updateUserPassword = await Member.findOneAndUpdate(
      { resetPasswordToken: resetPasswordToken },
      { $set: { password: hashedPassword } },
      { new: true }
    );

    return res.redirect("/auth/login");
  } catch (error) {
    console.log(error);
  }
};