# 🚀 Node.js + MongoDB (Mongoose) Project

This is a  Node.js project using Express and MongoDB with Mongoose for data modeling.



## 📁 How to Run This Project Locally

### 1. Prerequisites

Make sure you have the following installed:

- [Node.js](https://nodejs.org/) (v14 or higher)
- [MongoDB](https://www.mongodb.com/try/download/community) (Local or Atlas)



### 2. Install Dependencies

In the project folder, open your terminal and run:

```bash
npm install

```
### 3.Create a .env file in the root directory of the project, and add:

PORT=4000 || <Your_Port_number_where_application_wants_to_run>
MONGO_URI=mongodb://localhost:27017/your-db-name || <your_mongodb_url>

JWT_SECRET= <your_jwt_secret>


HOST=smtp.gmail.com
USER=<email_address_for_sendingEMail>
PASS=<application_password_which_are_generated_in_google_application> 
```
### 4. start the server

```bash
npm start


```
<GYM RECOMMENDATION & FINDER>

**Admin Credentials**
username: admin1@yopmail.com
password: admin

**Gym-Owner Credentials**
username: owner1@yopmail.com
password: owner

**Gym-Member Credentials**
username: member1@yopmail.com
password: member1

```
