const jwt = require("jsonwebtoken")
const Member = require("../models/memberModel");
const {    default: mongoose } = require("mongoose");
exports.isAuth = async (req, res, next) => {
  try {
    let accessToken = req.session?.accessToken || req.headers.authorization?.split(" ")[1];
        const useri = req.user ? req.user : null
       if(!accessToken)
       {
        return res.redirect("/auth/login")
       }
    const decoded = jwt.verify(accessToken, process.env.JWT_SECRET);
     
    const user = await Member.findById(new mongoose.Types.ObjectId(decoded.id));
  
    if (!user) {
      return res.render("auth/login" , { title: "Login" , error: "user is not found." ,user : useri})
    }

    req.user = user || null; // Attach user to request
    next();
  } catch (error) {
    console.error("Auth Middleware Error:", error);
    return res.render("auth/login", {
      title: "Login page",
      error : `something went wrong, ${error}`
    })
  }
};
