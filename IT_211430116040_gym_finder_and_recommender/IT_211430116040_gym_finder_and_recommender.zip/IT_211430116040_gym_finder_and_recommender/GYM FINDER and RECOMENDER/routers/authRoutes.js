const express = require("express");

const router = express.Router()

const auth = require("../controllers/authController")
const {isAuth} = require("../middleware/isauth")
router.get("/signup" , auth.getSignupPage)
router.get("/login" , auth.getLoginPage)
router.get("/verify-email", auth.verifyEmail)
router.post("/send-otp" , auth.sendOtp)
router.post("/signup" , auth.signup)
router.post("/login" , auth.login)
router.get("/logout" , auth.logout)
router.get("/my-profile" ,isAuth, auth.getProfile)
router.get("/edit-profile" ,isAuth, auth.geteditProfile)
router.post("/edit-profile" ,isAuth, auth.editProfile)
router.post("/edit-profile-image" ,isAuth, auth.geteditProfileImage)
router.post("/my-profile/reset-password" , isAuth , auth.resetPasseordPofile)


router.post("/forgot-password" ,auth.forgotPassword )

router.get("/forgot-password" ,auth.getForgotPassword )
router.get("/reset-password/:token" ,auth.getResetPassword )
router.post("/reset-password" , auth.resetPassword)


module.exports = router;
