const express = require("express");

const router = express.Router();
const { body } = require("express-validator");
const gym = require("../controllers/gymControllers");
const {isAuth} = require("../middleware/isauth")

// ********************************************************
// **********************GET ROUTES************************
// ********************************************************

router.get("/gym-details", isAuth , gym.getGymDetails);
router.get("/gym-details/:id", isAuth , gym.getGiveGymDetails);


router.get("/mygym-details" , isAuth , gym.getSpecificGymDetails)
router.get("/add-gym", isAuth, gym.getAddGym);
router.get("/edit-gym/:id",isAuth, gym.getEditGym);
router.get("/delete-gym/:id",isAuth, gym.deleteGym);

// ********************************************************
// **********************POST ROUTES***********************
// ********************************************************

router.post(
  "/add-gym",isAuth,
  [
    body("gymName")
      .isString()
      .trim()
      .isLength({ min: 3 })
      .withMessage("Title Has minimum 3 length required."),
    body("gymDescription")
      .isString()
      .trim()
      .isLength({ min: 3 })
      .withMessage("owner Has minimum 3 length required.."),
    body("status").isString().trim().withMessage("please enter valid status."),
  ],
  gym.postAddGym
);
router.post(
  "/edit-gym",isAuth,
  [
    body("gymName")
      .trim()
      .isString()
      .isLength({ min: 3, max: 50 })
      .withMessage("Name Has minimum 3 length required."),
    body("gymDescription")
      .trim()
      .isString()
      .isLength({ min: 3, max: 50 })
      .withMessage("Owner Has minimum 3 length required.."),
    body("status").isString().trim().withMessage("please enter valid status."),
  ],
  gym.postEditGym
);

router.get("/filter-gym",isAuth, gym.gymFilter);

router.get("/sort",isAuth, gym.sortGym);

module.exports = router;
