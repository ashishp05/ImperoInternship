const express = require("express");

const router = express.Router();

const record = require("../controllers/recordControllers");
const { body, check } = require("express-validator");
const {isAuth} = require("../middleware/isauth")
// ********************************************************
// **********************GET ROUTES************************
// ********************************************************

router.get("/record-details",isAuth, record.getBookingDetails);

router.get("/edit-booking/:bookingId",isAuth, record.getEditBookingForm);
router.get("/book-now/:gymId", isAuth , record.getBookingRecord)
router.post("/book-now/:gymId" , isAuth , record.postBooking)
router.post('/edit-booking/:bookingId',isAuth , record.updateBookingStatus);
router.get('/delete-booking/:bookingId',isAuth, record.deleteBooking);
// ********************************************************
// **********************POST ROUTES***********************
// ********************************************************


module.exports = router;
