const express = require("express");
const router = express.Router();
const isAuth = require("../middleware/isauth")
const home = require("../controllers/homeControllers");

router.get("/dashboard" ,isAuth.isAuth , home.getDashboard)
router.get("/aboutus" ,isAuth.isAuth, home.getAboutPage)
router.get("/contactus" ,isAuth.isAuth,home.getContactPage)
router.get("/home" ,isAuth.isAuth, home.getHomePage)
module.exports = router;
