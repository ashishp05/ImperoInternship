const express = require("express");

const router = express.Router();

const { body, check } = require("express-validator");

const member = require("../controllers/memberControllers");
const {isAuth} = require("../middleware/isauth")
// ********************************************************
// **********************GET ROUTES************************
// ********************************************************

router.get("/member-details",isAuth, member.getMemberDetails);
router.get("/mymember-details" , isAuth , member.getAdminMemberDetails)
router.get("/add-member",isAuth, member.getAddMember);
router.get("/edit-member/:id", isAuth,member.geteditMember);

//****delete-memeber using link not a form***************

router.get("/delete-member/:id",isAuth, member.deleteMember);

// ********************************************************
// **********************POST ROUTES***********************
// ********************************************************

router.post(
  "/add-member",isAuth,
  [
    body("name")
      .trim()
      .isString()
      .isLength({ min: 3, max: 50 })
      .withMessage("Name has minimum 3 length."),
    check("email").isEmail().withMessage("email has minmum 3 length."),
  ],
  member.addMemeber
);
router.post(
  "/edit-member",isAuth,
  [
    body("name")
      .trim()
      .isString()
      .isLength({ min: 3, max: 50 })
      .withMessage("Name is invalid "),
    check("email").isEmail().withMessage("email is invalid "),
  ],
  member.postEditMember
);

router.get("/filter-member",isAuth, member.filterMember);
router.get("/sort",isAuth, member.sortMember);
router.post("/update-memberstatus" ,isAuth,member.postToggleUser)
module.exports = router;
